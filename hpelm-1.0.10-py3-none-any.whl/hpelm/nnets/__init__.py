# -*- coding: utf-8 -*-
"""
Created on Wed Sep 23 18:49:20 2015

@author: akusok
"""

from .slfn import SLFN
#from slfn_skcuda import SLFNSkCUDA